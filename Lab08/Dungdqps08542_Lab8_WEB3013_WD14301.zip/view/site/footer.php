        <footer>
        PHP2- Trang User
        </footer>
