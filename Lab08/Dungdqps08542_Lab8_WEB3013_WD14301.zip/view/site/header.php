    <header>
      <img src="assets/images/banner.jpg">
    </header>
    <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php?ctrller=home">Trang chủ</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="index.php?ctrller=flights">ADD Flights</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="index.php?ctrller=book">Đặt vé</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="index.php?ctrller=cart">Your cart</a>
        </li>
      </ul>
    </nav>