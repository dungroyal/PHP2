<div class="container">
    <div class="card">
      <div class="card-header">
        Chi tiet sản phẩm
      </div>
      <div class="card-body">
          <div class="row">
            <div class="col-6">
                Product: Gardent cart<br>
                Code: GC-123<br>
                Available: 2020-04-27<br>
                Price: $8.8<br>
                5 Star Rating: 4.2<br>
            </div>
            <div class="col-6">
              <img src="view/images/gardencart.png" width="300px">';
            </div>
          </div>
      </div>
    </div>
</div>
