<div class="container">
  <div class="card">
    <div class="card-header">
      Danh sách sản phẩm
    </div>
    <div class="card-body">
        <table class="table">
          <thead>
              <tr>
                <th>Images</th>
                <th>Product</th>
                <th>Code</th>
                <th>Available</th>
                <th>Price </th>
                <th>5 Star Rating</th>
              </tr>
          </thead>
          <tbody>
            <tr>
                    <td><img src="view/images/gardencart.png" width="50px"></td>
                    <td>
                      <a href="#">Garden Cart</a>
                    </td>
                    <td>GC-0123</td>
                    <td>2020-04-27</td>
                    <td>8.9</td>
                    <td>4.2</td>
                  </tr>
          </tbody>
      </table>
    </div>
  </div>
</div>
