<div class="container">
    <form method="post" action="#">
      <div class="form-group">
        <label>Chọn chuyến bay</label>
        <select class="form-control" name="flight">
          <option value="" selected>---Chọn chọn chuyến---</option>
          <option value="">VietName to Paris</option>
        </select>
      </div>
      <div class="form-group">
        <label>Nhập tên của bạn</label>
        <input type="text" class="form-control"  placeholder="input your name" name="name">
      </div>
      <div class="form-group">
      <button type="submit" class="btn btn-primary" name="btnBook">Đăng ký</button>
      </div>
    </form>
    <div class="card">
      <div class="card-header">
        Danh sách hành khách đã đăng ký bay
      </div>
      <div class="card-body">
          <table class="table">
            <thead>
                <tr>
                  <th>Mã khach</th>
                  <th>Tên hành khách</th>
                  <th>Xuất phát</th>
                  <th>Điểm đến</th>
                  <th>Thời lượng</th>
                </tr>
            </thead>
            <tbody>
            <tr>
                      <td>01</td>
                      <td>Trần Công Mua</td>
                      <td>Tp.Hồ Chí Minh</td>
                      <td>Đà Nẵng</td>
                      <td>1h</td>
                    </tr>
            </tbody>
        </table>
      </div>
    </div>
</div>
