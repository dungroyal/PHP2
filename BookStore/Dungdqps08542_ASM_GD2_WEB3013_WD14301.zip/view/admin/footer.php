</div>
    </div>
    <script type="text/javascript" src="../view/admin/assets/scripts/main.js"></script>
</body>

</html>