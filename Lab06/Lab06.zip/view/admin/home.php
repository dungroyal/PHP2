<br><br><br><br><br>
<h2>Xin chào <strong>"<?php echo $_SESSION['admin'];?>"</strong>  :v</h2>
<br><br><br><br><br>