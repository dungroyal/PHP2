<form method="POST" action="index.php?ctrller=user&act=login">
        <table style="margin: 0px auto;">
            <tr>
                <td colspan="2"><span style="font-weight:bold;font-size:20px;"><center style="margin-bottom: 20px;">ĐĂNG NHẬP QUẢNG TRỊ</center></span></td>
            </tr>
            <tr>
                <td>Tên đăng nhập: </td>
                <td><input type="text" name="user" size="20"></td>
            </tr>
            <tr>
                <td>Mật khẩu: </td>
                <td><input type="password" name="pass" size="20"></td>
            </tr>
            <tr>
                <td colspan="2" align="right"> <input name="btn_login" type="submit" value="Đăng nhập"></td>
            </tr>
        </table>
    </form>