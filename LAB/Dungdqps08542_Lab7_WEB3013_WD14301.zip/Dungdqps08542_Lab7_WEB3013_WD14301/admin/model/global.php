<?php
    $content_contact = '<!DOCTYPE html>
					<html lang="en">
					<head>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, initial-scale=1.0">
						<meta http-equiv="X-UA-Compatible" content="ie=edge">
						<style>
							* {box-sizing: border-box;}							
							body {margin: 0px auto;width: 70%;}
							header {background-color: #f1f1f1;padding: 20px;text-align: center;}
						</style>
					</head>	
					<body>
						<header>
							<img src="http://choviet.xyz/view/img/logo/logo.png" alt="Logo" style="width:300px;text-align: center; margin: 0px auto;">
							<h1>Xin chào quý khách</h4>
								<h3>Cảm ơn bạn đã liên hệ với chúng tôi, shop sẽ liên hệ với bạn trong thời gian ngắn nhất.</h3>
						</header>
						<h1></h1>
					</body>	
					</html>';

?>