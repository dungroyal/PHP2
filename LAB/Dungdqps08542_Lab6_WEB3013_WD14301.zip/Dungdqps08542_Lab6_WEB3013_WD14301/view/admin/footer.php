        <footer>
        PHP2- Trang Quan Tri
        </footer>
    </div>
</body>
</html>